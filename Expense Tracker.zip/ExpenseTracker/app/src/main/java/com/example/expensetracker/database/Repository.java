package com.example.expensetracker.database;

public class Repository {
    private ExpenseDAO mExpenseDAO;
}
